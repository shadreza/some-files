module.exports = {
  images: {
    domains: [
      "i.ibb.co",
      "firebasestorage.googleapis.com",
      "platform-lookaside.fbsbx.com",
    ],
  },
}