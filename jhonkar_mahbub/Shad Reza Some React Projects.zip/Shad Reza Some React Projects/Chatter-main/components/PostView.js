function PostView() {
    return (
        <div>
            
        </div>
    )
}

export default PostView
