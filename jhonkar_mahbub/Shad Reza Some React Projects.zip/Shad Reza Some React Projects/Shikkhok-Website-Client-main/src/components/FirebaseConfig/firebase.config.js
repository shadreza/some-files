const firebaseConfig = {
    apiKey: "AIzaSyAFSCwUTzHLYrBJemdG6y6CWxWfWUvvXMo",
    authDomain: "hay-store.firebaseapp.com",
    projectId: "hay-store",
    storageBucket: "hay-store.appspot.com",
    messagingSenderId: "704874589638",
    appId: "1:704874589638:web:010bf5aff47566533dd6c7",
    measurementId: "G-2S61QZX0XD"
  };
  export default firebaseConfig;