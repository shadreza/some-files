# shikkhok

# features :

1. Used React In Front End & MongoDb In Back End
2. Main Actions Are Done Only By Logging In done with firebase authentiaccation 
3. Admin Can Add Courses of instructors
4. Admin Can Delete Course
5. Customer Can Buy Course
6. Customer Can See His/Her Purchase History
7. Checkout Page For Confirmative Purchase
8. Image File Can Be Uploaded
9. Automatic Updates With Out Any Kind Of Refreshing
10. Admin can add or remove other Admin
11. Responsive Web Analytics

# git link for client side : https://github.com/shadreza/Shikkhok-Website-Client.git

# git link for server side : https://github.com/shadreza/Shikkhok-Website-Server.git

# live site link : https://hay-store.web.app/

