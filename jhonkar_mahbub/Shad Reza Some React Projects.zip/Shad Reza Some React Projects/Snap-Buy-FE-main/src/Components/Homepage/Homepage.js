import React from 'react';
import './Homepage.css';
const Homepage = () => {
    return (
        <div>
            
        </div>
    );
};

export default Homepage;