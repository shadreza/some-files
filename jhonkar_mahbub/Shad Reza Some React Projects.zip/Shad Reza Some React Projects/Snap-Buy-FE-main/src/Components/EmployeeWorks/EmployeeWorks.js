import React from 'react';
import './EmployeeWorks.css';

const EmployeeWorks = () => {
    return (
        <div>
            
        </div>
    );
};

export default EmployeeWorks;