import React from "react";

function Profile() {
  return (
    <div>
        <div className="side_bar">
            
            <p>Sidebar </p>
        </div>
    </div>
  );
}

export default Profile;
