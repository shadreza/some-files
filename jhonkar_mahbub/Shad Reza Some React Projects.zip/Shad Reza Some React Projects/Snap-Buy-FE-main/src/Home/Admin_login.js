import React from 'react';

const Admin_login = () => {
    return (
        <div>
            
        </div>
    );
}

export default Admin_login;
