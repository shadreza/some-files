// this is the firebase config file from the firebase website

const firebaseConfig = {
    apiKey: "AIzaSyA23dcIL94d05PKG88-4XGQeZeHgI5Gxwo",
    authDomain: "civic-shifter.firebaseapp.com",
    projectId: "civic-shifter",
    storageBucket: "civic-shifter.appspot.com",
    messagingSenderId: "971237895220",
    appId: "1:971237895220:web:a29fc1192326533bfbee61"
  };

export default firebaseConfig;