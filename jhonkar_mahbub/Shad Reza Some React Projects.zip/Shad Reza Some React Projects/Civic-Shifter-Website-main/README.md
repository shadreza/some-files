# Civic-Shfter

an online riding website that has similarities of uber & pathao

# github Link : https://github.com/shadreza/Civic-Shifter-Website.git

# live site link : https://civic-shifter.web.app/

# features:

1. sign in option with google and email
2. showing user photo , name and email after login
3. login and log out toggles
4. responsiveness done dynamic breakpoints
5. implementation of private route was done
6. also learned the alternative to private route by the help of conditionals
7. password validation for 6 length
8. name validation must be at least one character
9. email validation provided
10. if the user is not logged in then the internal things are not shown to him or encapsuled
11. if the user doesn't fill data properly then it will not let him move forward
12. if the transport is not selected then it will not be able to move forward to destination
13. the user profile photo is set t be dynamic as if the user is not logged in then nothing will show and if the user is logged in but no image is attached to it then it will display a default image but when image is attached then it will show that picture
14. if the user photo is clicked then the information of the user is shown
15. google map was implemented here
16. name of the user is shown in the riding page
17. commented code for better understanding in the github repo

# Special Thanks to Jhankar Vai & PH team for increasing one day as I really am satisfied with the coding

# Alhamdulillah Done
